# PS3-Database-Rebuilder
Homebrew to rebuild the PS3 Database after reboot

Install the homebrew on your Ps3 CFW, launch it, say "yes", the console will reboot and rebuild the database.
