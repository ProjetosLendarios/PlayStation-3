PLAYSTATION(R)3 Theme Builder 1.6

Thanks for downloading and using this software, PS3ThemeManager.exe is a program that helps in the creation of PLAYSTATION(R)3 theme files by 
automatically building XML files and generating p3t files based on the input give it via the front end.

Sound Effects
=============================
Sound effects are working.

There are several things you must do before you can use them!
1. The total size of your sound effects Must not exceed 256k!
2. Sound effects must be in VAG file format
   2a. You can convert almost any sound file to VAG using MFAudio v1.1
   2b. Search google for MFAudio v1.1.

3. Sound support may not be 100% working, if you have errors... please let me know, but I don't gurarantee anything.



INSTALLING THE SOFTWARE
=======================

1. If you do not already have it installed,  Download and Install the Microsoft .Net framework 2.0.
   It is about a 22 megabyte download and is required to use Theme Builder.
   It can be found at the below URL: 
   http://www.microsoft.com/downloads/details.aspx?familyid=0856eacb-4362-4b0d-8edd-aab15c5e04f5&displaylang=en
   

2. Download My PS3 Theme Manager (Which you likely have already if you are reading this)

3. Extract all files from this archive to the same directory that you unzipped Sony's theme builder software to

4. Run PS3ThemeManager.exe


p3textractor.exe Installation
=============================
I have included this with the latest release.

